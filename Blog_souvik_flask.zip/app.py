from flask import Flask,render_template,request
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/SouvikBlog'
app.config['SQLALCHEMY_MODIFICATIONS'] = True
db=SQLAlchemy(app)
app.app_context().push()

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(12), nullable=False)
    des = db.Column(db.String(300), nullable=False)


@app.route('/')
def index():
    return render_template('index.html')
@app.route("/contact", methods=["POST","GET"])
def contact():
    if(request.method=="POST"):
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        des = request.form.get('des')
        new_contact = Contact(name=name, email=email, phone=phone, des=des)
        db.session.add(new_contact)
        db.session.commit()
        
    
    return render_template('contact.html')
@app.route("/about")
def about():
    return render_template('about.html')
@app.route("/service")
def service():
    return render_template('service.html')



if __name__ == '__main__':
    app.run(debug=True)